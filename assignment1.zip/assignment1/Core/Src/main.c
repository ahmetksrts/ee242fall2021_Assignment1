
// main starts:
int main(void)
{
	*((int *) 0x40023830) = 0x00000008U; // 1U<<3U // 0x40023830 = Address of RCC_AHB1ENR we need
	*((int *) 0x40020c00) = 0x40000000U; // 0x40020c00 = Address of GPIOD_MODER
	*((int *) 0x40020c14) = 0x00008000U; // 0x40020c14 = Address of GPIOD_ODR
	// Since 527%4=3, I should light led number 3 which is blue led
	return 0;
}
