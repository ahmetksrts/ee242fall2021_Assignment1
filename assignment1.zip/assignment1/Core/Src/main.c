
// main starts:
int main(void)
{
	*((int *) 0x40023830) = 0x00000008U; // 1U<<3U  // 0x40023830 = Address of RCC_AHB1ENR we need
	*((int *) 0x40020c00) = 0x40000000U; // 1U<<30U // 0x40020c00 = Address of GPIOD_MODER we need
	*((int *) 0x40020c14) = 0x00008000U; // 1U<<15U // 0x40020c14 = Address of GPIOD_ODR we need
	/*	Since a + h + m + e + t = 97+104+109+101+116 = 527 (for ASCII table), and 527 % 4 = 3.
		The resulting number is my led number (Which is led number 3: blue).
	*/
	/*
		1U<<3U  --> Shifting 1 to 3
		1U<<15U --> Shifting 1 to 15
		1U<<30U --> Shifting 1 to 30
	*/
	return 0;
}
